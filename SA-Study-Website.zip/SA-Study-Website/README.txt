SA STUDY — FREE WEBSITE

1. Open GitHub in your tablet browser and create a free account.
2. Create a new PUBLIC repository, for example: sa-study.
3. Upload index.html and the entire assets folder.
4. In the repository open Settings -> Pages.
5. Under Build and deployment choose "Deploy from a branch".
6. Choose the main branch and the / (root) folder, then Save.
7. GitHub will give you a free URL similar to:
   https://YOUR-USERNAME.github.io/sa-study/

The website is intentionally a single HTML file plus three image assets.
The plane backgrounds automatically rotate every 8 seconds.
Tasks and notes are saved in the visitor's browser using localStorage.
